#  Java_IO总结

@(BigData)[大数据基础, java, IO, 总结, 读写文件处理]

----------
[toc]

Java将程序对系统文件磁盘的读写操作抽象为了I/O(Input/Output) 输入流/输出流。

## Java IO 架构设计图
![Alt text](./1458480775155.png)
图片已经注明出处



